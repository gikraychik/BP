/*
var g_pageChangeDuration = 300;
var g_pageHeight = 0;
var g_pageContainer = '.content';
var g_shiftSize = $(window).width();
var g_pageShift = g_shiftSize;

$( window ).resize(function() {
	g_shiftSize = $(window).width();
});

if ($.support.pjax) {
	function changePage (changeContentFunc, direction) {
		g_pageHeight = $(g_pageContainer).outerHeight();

		g_pageShift = (direction == 'forward') ? 
			g_shiftSize : -g_shiftSize

		$(g_pageContainer).animate({
				opacity: 0,
				marginLeft: "-="+g_pageShift,
			}, 
			g_pageChangeDuration, function(){
				changeContentFunc()
			}
		)
	}

	//Tag <a> handler
	$(document).on('click', 'a', function(event) 
	{
		event.preventDefault();
		var newPageUrl = $(this).attr('href');
		changePage (function () {
			$.pjax({
				url: newPageUrl,
				container: g_pageContainer
			});
		}, 'forward')
	})

	//Navigation handler
	$(window).on('popstate', function(event) 
	{
		changePage(function () {
			$.pjax.navigation(event)
		}, $.pjax.getNavDirection(event))
	});

	//Process state handlers
	$(document).on('pjax:beforeReplace', function() 
	{
		$(g_pageContainer).parent().css({
			"height": g_pageHeight
		});
	})

	$(document).on('pjax:end', function() 
	{
		$(g_pageContainer).parent().animate({
			height: $(g_pageContainer).outerHeight()
		}, g_pageChangeDuration/2);

		$(g_pageContainer)
		.css({'marginLeft':g_pageShift})
		.animate({
			marginLeft: "0",
			opacity: 1
		});
	})
}
*/