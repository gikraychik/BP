	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-3">
				<div class="box">
					<?php echo Block::get("home-left"); ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="box">			
					<?php echo Site::content(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="box">
					<?php echo Block::get("home-right"); ?>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-3">
					<?php echo Block::get("home-left-bottom"); ?>
			</div>
			<div class="col-md-6">			
					<?php echo Block::get("home-center-bottom"); ?>
			</div>
			<div class="col-md-3">
					<?php echo Block::get("home-right-bottom"); ?>
			</div>
		</div>
	</div>