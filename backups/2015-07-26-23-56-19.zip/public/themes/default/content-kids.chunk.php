	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-4">
				<div class="box">			
					<?php echo Site::content(); ?>
				</div>
			</div>
			<div class="col-md-8">
				<div class="box">
					Карусель
				</div>
			</div>
		</div>
	</div>