	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-8">			
					<?php echo Site::content(); ?>
			</div>
			<div class="col-md-3">
				пам
			</div>
			<div class="col-md-1">
				пам
			</div>
		</div>
	</div>