<?php $isAjaxRequest = isset($_SERVER['HTTP_X_PJAX']); ?>

<?php if(!$isAjaxRequest){ ?>

	<?php Chunk::get('header'); ?>
	<body id="price">
		<div class="container-fluid nav">
			<?php echo Menu::get(); ?>
		</div>
		<br clear="all"/>
	<?php Chunk::get('content-price'); ?>
	<?php Chunk::get('footer'); ?>
	
<?php } else {
	 Chunk::get('content-price'); 
}?>
	