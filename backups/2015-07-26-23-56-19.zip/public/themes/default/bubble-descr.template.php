<?php 
$isAjaxRequest = isset($_SERVER['HTTP_X_PJAX']); 
$content_name = 'content-descr';
?>

<?php if(!$isAjaxRequest){ ?>

	<?php Chunk::get('header'); ?>
	<!--
	<body>
		<div class="navbar navbar-default navbar-static-top">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
        		</div>
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav">
						<?php echo Menu::get(); ?>
						<div style="clear: both;"></div>
					</ul>
				</div>
			</div>
		</div>
		<br clear="all"/>
		-->
		<body>
		<div class="container-fluid nav">
			<?php echo Menu::get(); ?>
		</div>
		<br clear="all"/>
	<?php Chunk::get($content_name); ?>
	<?php Chunk::get('footer'); ?>
	
<?php } else {
	 Chunk::get($content_name); 
}?>
	