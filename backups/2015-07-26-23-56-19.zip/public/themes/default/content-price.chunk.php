	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-4">			
					<div class="button">
						5850
					</div>
			</div>
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="item">
							Студент
						</div>
						<a class="big circle button" href="#">
							5%
						</a>
						<div class="item">
							День рождения
						</div>
						<a class="big circle button" href="#">
							10%
						</a>
						<div class="item">
							Скидка дня
						</div>
						<a class="big circle button" href="#">
							5%
						</a>
					</div>
					<div class="col-md-6">
						<div class="item">
							Школьник
						</div>
						<a class="big circle button" href="#">
							5%
						</a>
						<div class="item">
							Будни
						</div>
						<a class="big circle button" href="#">
							20%
						</a>
						<div class="item">
							От 2-х часов
						</div>
						<a class="big circle button" href="#">
							20%
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>