   <footer class="navbar navbar-fixed-bottom footer"> 
		<div class="container">
            <div class="col-md-4 phone">
            	<?php echo Block::get("footer-left"); ?>
            </div>
			<div class="col-md-4 ambly">
				<?php echo Block::get("footer-center"); ?>
			</div>
			<div class="col-md-4 social">
				<?php echo Block::get("footer-right"); ?>
			</div>
		</div>
	</footer>


	<script type="text/javascript" src="<?php echo Option::get('siteurl'); ?>/public/assets/js/jquery.pjax.js"></script>
	<script type="text/javascript" src="<?php echo Option::get('siteurl'); ?>/public/themes/default/js/content_changer.js"></script>

  </body>
</html>
