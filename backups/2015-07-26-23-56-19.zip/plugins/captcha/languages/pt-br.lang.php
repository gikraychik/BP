<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Plugin de captcha para o Monstra CMS',
            'Captcha code is wrong' => 'O Captcha está errado',
        )
    );
