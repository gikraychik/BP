<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha plugin per Monstra',
            'Captcha code is wrong' => 'Codice captcha è errato',
        )
    );
