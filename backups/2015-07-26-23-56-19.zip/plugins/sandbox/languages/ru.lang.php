<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Песочница',
            'Sandbox plugin for Monstra' => 'Плагин песочница для Monstra',
            'Sandbox template' => 'Шаблон песочницы',
            'Save' => 'Сохранить',
        )
    );
