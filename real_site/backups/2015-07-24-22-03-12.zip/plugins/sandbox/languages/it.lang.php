<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Plugin Sandbox per Monstra',
            'Sandbox template' => 'Modello Sandbox',
            'Save' => 'Salva',
        )
    );
