<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Deneme',
            'Sandbox plugin for Monstra' => 'Monstra için deneme/test eklentisi',
            'Sandbox template' => 'Deneme şablonu',
            'Save' => 'Kaydet',
        )
    );
