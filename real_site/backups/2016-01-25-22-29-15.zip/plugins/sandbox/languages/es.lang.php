<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox plugin para Monstra',
            'Sandbox template' => 'Plantilla sandbox',
            'Save' => 'Guardar',
        )
    );