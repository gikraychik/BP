<?php
	echo Blog::getPost();
?>