	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-12">		
					<?php echo Site::content(); ?>
			</div>
		</div>
	</div>