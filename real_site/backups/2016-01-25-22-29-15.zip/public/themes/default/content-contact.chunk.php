	<div class="container-fluid content">
			<div class="row">
				<div class="col-md-6">
					<?php echo Site::content(); ?>
				</div>
				<div class="col-md-6">
					<div id="googleMap" class="google-map"></div>
				</div>
			</div>
	</div>