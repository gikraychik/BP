<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Wtyczka Sandbox dla systemu Monstra',
            'Sandbox template' => 'Szablon Sandbox',
            'Save' => 'Zapisz',
        )
    );
