<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Verifikasi',
            'Captcha plugin for Monstra' => 'Verifikasi plugin untuk Monstra',
            'Captcha code is wrong' => 'Kode Verifikasi salah',
        )
    );
