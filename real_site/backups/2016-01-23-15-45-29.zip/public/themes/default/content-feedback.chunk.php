<div class="container-fluid content">
    <div class="container-wide">
        <div class="box">
            <?php echo Site::content(); ?>
            <div class="vk-comments-block" id="vk-comments"></div>

        </div>
    </div>
</div>