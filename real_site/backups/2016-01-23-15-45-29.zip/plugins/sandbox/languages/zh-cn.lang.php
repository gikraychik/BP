<?php

    return array(
        'sandbox' => array(
            'Sandbox' => '沙盒',
            'Sandbox plugin for Monstra' => 'Monstra 沙盒插件',
            'Sandbox template' => '沙盒模板',
            'Save' => '保存',
        )
    );
