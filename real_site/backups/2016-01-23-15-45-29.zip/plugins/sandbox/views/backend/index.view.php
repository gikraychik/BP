Sandbox backend view
