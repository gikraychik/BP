<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox papildinys',
            'Sandbox template' => 'Sandbox šablonas',
            'Save' => 'Išsaugoti',
        )
    );
