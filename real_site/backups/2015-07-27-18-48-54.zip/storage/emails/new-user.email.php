Welcome to <?php echo $site_name; ?>!
<br><br>
Dear <?php echo $user_login; ?>,
<br><br>
Thanks for registering at <?php echo $site_name; ?>!<br> We are glad you have chosen to be a part of our community and we hope you enjoy your stay.
<br><br>
All the best,<br>
<?php echo $site_name; ?>
