CodeMirror
======================

CodeMirror is a versatile text editor implemented in JavaScript for the browser.