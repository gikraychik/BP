Sandbox frontend view
