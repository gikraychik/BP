<?php 
$isAjaxRequest = isset($_SERVER['HTTP_X_PJAX']); 
$content_name = 'content-usual';
?>

<?php if(!$isAjaxRequest){ ?>

	<?php Chunk::get('header'); ?>
	<body>
		<div class="container-fluid nav">
			<?php echo Menu::get(); ?>
		</div>
		<br clear="all"/>
	<?php Chunk::get($content_name); ?>
	<?php Chunk::get('footer'); ?>
	
<?php } else {
	 Chunk::get($content_name); 
}?>
	