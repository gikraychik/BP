	<div class="container-fluid content">
		<div class="container-wide">
			<div class="box">
				<?php echo Site::content(); ?>
			</div>
		</div>
	</div>