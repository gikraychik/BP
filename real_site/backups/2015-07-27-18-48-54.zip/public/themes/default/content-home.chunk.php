	<div class="container-fluid content">
		<div class="row">
			<div class="col-md-3">
					<h2>Бесплатная фотосъёмка</h2>
			</div>
			<div class="col-md-6">
				<div class="box">			
					<center><img src="http://bubble-park.ru/public/uploads/logo.png" alt=""/></center>
					<?php echo Site::content(); ?>
				</div>
			</div>
			<div class="col-md-3">
					<h2>Активный отдых</h2>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-3">
					<h2>Безопасное развлечение</h2>
			</div>
			<div class="col-md-6">			
					<?php echo Block::get("home-left-bottom"); ?>
			</div>
			<div class="col-md-3">
					<h2>От 400 рублей за человека</h2>
			</div>
		</div>
		
	</div>