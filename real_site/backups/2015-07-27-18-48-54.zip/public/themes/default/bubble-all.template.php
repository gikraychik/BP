<?php 
$isAjaxRequest = isset($_SERVER['HTTP_X_PJAX']);

//get current page name
$page_url_pieces = explode('/', Url::current());
$page_name = $page_url_pieces[count($page_url_pieces)-1];
if ($page_name == 'index') {
	$content_name = 'content-home';
}
?>

<?php if(!$isAjaxRequest){ ?>

	<?php Chunk::get('header'); ?>
	<body id="home">
		<?php Action::run('theme_pre_content'); ?>
		<div class="container-fluid nav">
			<?php echo Menu::get(); ?>
		</div>
		<br clear="all"/>
		<?php Chunk::get($content_name); ?>
		<?php Action::run('theme_post_content'); ?>
	<?php Chunk::get('footer'); ?>
	
<?php } else {
	 Chunk::get($content_name); 
}?>
	